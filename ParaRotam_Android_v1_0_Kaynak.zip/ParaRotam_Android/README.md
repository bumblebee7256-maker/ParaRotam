# ParaRotam Android v1.0

Bu proje ParaRotam v1.0 HTML arayüzünü Android WebView içinde çevrimdışı çalıştırır.

## APK oluşturma
1. Bilgisayarda Android Studio'yu açın.
2. **Open** ile bu klasörü seçin.
3. Gradle senkronizasyonunun bitmesini bekleyin (ilk seferde internet gerekir).
4. **Build > Build Bundle(s) / APK(s) > Build APK(s)** seçin.
5. APK `app/build/outputs/apk/debug/app-debug.apk` yolunda oluşur.

Google Play için ayrıca imzalı Android App Bundle (AAB), geliştirici hesabı ve mağaza politikalarına uyum gerekir.

## Önemli
- Finans verileri WebView localStorage alanında tutulur; uygulamayı kaldırmak verileri siler.
- HTML dosyası ve Android uygulaması farklı depolama alanları kullanır. Önceki sürümden JSON yedek alın ve uygulamada Ayarlar > Yedek yükle üzerinden geri yükleyin.
- Bu paket kaynak projedir; APK değildir. Bu ortamda Android SDK / Gradle bulunmadığından APK derlenip cihazda test edilemedi.
- Android dosya seçicisiyle JSON içe aktarma desteklenir. HTML'nin tarayıcı indirme mekanizması üzerinden JSON dışa aktarma işlemi bazı Android WebView sürümlerinde çalışmayabilir; gerçek cihazda ayrıca test edilmelidir.
